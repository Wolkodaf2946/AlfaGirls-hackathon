import json
import ollama
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def json_to_text(data):
    """Превращает JSON в строку для векторного анализа."""
    if isinstance(data, dict):
        return " ".join([str(v) for k, v in data.items() if k != 'id'])
    return str(data)

def get_top_candidates(target_json, candidates_list, top_k=5):
    """
    Быстрый фильтр через TF-IDF. 
    Оставляет только N самых похожих товаров, чтобы не грузить LLM.
    """
    if len(candidates_list) <= top_k:
        return candidates_list

    # Подготовка данных
    target_text = json_to_text(target_json)
    candidates_text = [json_to_text(c) for c in candidates_list]
    corpus = [target_text] + candidates_text
    
    # Векторизация
    vectorizer = TfidfVectorizer().fit_transform(corpus)
    vectors = vectorizer.toarray()
    
    # Считаем схожесть целевого (0) со всеми остальными
    cosine_similarities = cosine_similarity(vectors[0:1], vectors[1:]).flatten()
    
    # Берем индексы лучших
    top_indices = cosine_similarities.argsort()[-top_k:][::-1]
    
    return [candidates_list[i] for i in top_indices]

def match_with_ollama(target_json, candidates_list, model_name="llama3"):
    """
    Функция матчинга через локальную LLM (Ollama).
    """
    # 1. Фильтрация (уменьшаем выборку до 5 штук)
    top_candidates = get_top_candidates(target_json, candidates_list, top_k=5)
    
    # 2. Подготовка промпта
    # Важно: локальные модели чувствительны к формату, просим строгий JSON
    system_prompt = """
    You are an expert entity resolution system. 
    Your task is to match a TARGET product with one from a list of CANDIDATES.
    Before the final answer, add some thoughts and add a thought element called "reasoning" to the final json
    
    Rules:
    1. Analyze titles, brands, specs, and attributes.
    2. Compare the quantities carefully. If they don't match, it is incorrect match, even if everything else matches.
    3. Account for slight variations in naming (e.g., "128GB" vs "128 Gb").
    4. Return the 'id' of the matching candidate.
    5. If NO candidate matches, return -1.
    6. Output MUST be a JSON object: {"reasoning": "<some thoughts>", "match_id": <number>}. Do not write any other text.
    """

    user_prompt = f"""
    TARGET PRODUCT:
    {json.dumps(target_json, ensure_ascii=False)}

    CANDIDATE LIST:
    {json.dumps(top_candidates, ensure_ascii=False)}
    
    Which candidate is the same product as the target?
    """

    try:
        # 3. Запрос к Ollama
        response = ollama.chat(
            model=model_name,
            messages=[
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': user_prompt},
            ],
            format='json', # Принудительный JSON режим (работает в Llama 3 / Mistral)
            options={'temperature': 0} # Нулевая температура для стабильности
        )
        
        # 4. Парсинг ответа
        print(response)
        content = response['message']['content']
        result_data = json.loads(content)
        
        # Пытаемся достать match_id, поддерживаем варианты (строка или число)
        match_id = result_data.get("match_id", -1)
        
        # Если модель вернула id как строку, приводим к int (если id числовые)
        try:
            return int(match_id)
        except:
            return match_id

    except Exception as e:
        print(f"Error communicating with Ollama: {e}")
        return -1

# ==========================================
# Тестирование
# ==========================================

# ==========================================
# РАСШИРЕННЫЕ ТЕСТЫ СИСТЕМЫ
# ==========================================

def run_test_case(test_name, target, catalog, expected_id, model):
    """
    Помощник для запуска теста и проверки результата.
    """
    print(f"\n{'='*60}")
    print(f"TEST: {test_name}")
    print(f"{'='*60}")
    
    # Вызываем основную функцию
    predicted_id = match_with_ollama(target, catalog, model_name=model)
    
    print(f"\n[RESULT] Ожидалось: {expected_id} | Получено: {predicted_id}")
    
    if predicted_id == expected_id:
        print("✅ SUCCESS")
    else:
        print("❌ FAILED")

if __name__ == "__main__":
    # Укажите здесь вашу модель (llama3, mistral, qwen2.5 и т.д.)
    # MODEL_NAME = "llama3" 
    MODEL_NAME = "qwen3-vl:8b-instruct-q8_0" # Используем ту, что была в вашем примере

    print(f"Запуск тестов на модели: {MODEL_NAME}\n")

    # ----------------------------------------------------------
    # ТЕСТ 1: Тонкие различия (Pro vs Non-Pro vs Аксессуар)
    # LLM должна понять, что "Case" (Чехол) - это не телефон.
    # ----------------------------------------------------------
    t1_target = {
        "title": "iPhone 13 Pro 256GB Graphite",
        "price": 90000
    }
    t1_catalog = [
        {"id": 10, "name": "Apple iPhone 13 256GB (Not Pro)"},
        {"id": 11, "name": "Case for iPhone 13 Pro Silicone"}, # Ловушка
        {"id": 12, "name": "Apple iPhone 13 Pro 128GB"},       # Не тот объем
        {"id": 13, "name": "Смартфон Apple iPhone 13 Pro 256GB, Графитовый"} # Верный
    ]
    run_test_case("Distractors & Model Check", t1_target, t1_catalog, 13, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 2: Проверка количества (Rule #2)
    # LLM должна отсеять товар, если не совпадает количество в упаковке.
    # ----------------------------------------------------------
    t2_target = {
        "name": "Coca-Cola Classic, 0.33л (Упаковка 12 штук)",
        "attr": "Pack of 12"
    }
    t2_catalog = [
        {"id": 20, "name": "Coca-Cola 0.33l can", "desc": "Single unit"},  # 1 шт
        {"id": 21, "name": "Coca-Cola 0.33l x 6 pack"},                     # 6 шт
        {"id": 22, "name": "Напиток Coca-Cola 330мл ж/б (12 шт в уп)"},     # Верный
        {"id": 23, "name": "Pepsi Cola 12 pack"}
    ]
    run_test_case("Quantity Mismatch Rule", t2_target, t2_catalog, 22, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 3: Грязные данные и единицы измерения
    # 1000g == 1kg. LLM должна это понять.
    # ----------------------------------------------------------
    t3_target = {
        "raw": "Кофе в зернах Lavazza Oro 1кг пакет"
    }
    t3_catalog = [
        {"id": 30, "title": "Lavazza Qualita Oro Ground 250g"},
        {"id": 31, "title": "Lavazza Oro Coffee Beans 1000g"}, # Верный (1кг = 1000г)
        {"id": 32, "title": "Lavazza Rossa 1kg"}
    ]
    run_test_case("Units Conversion (1kg vs 1000g)", t3_target, t3_catalog, 31, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 4: No Match (Rule #5)
    # Целевого товара нет в базе. Ожидаем -1.
    # ----------------------------------------------------------
    t4_target = {
        "name": "Samsung Galaxy S24 Ultra 512GB"
    }
    t4_catalog = [
        {"id": 40, "name": "Samsung Galaxy S23 Ultra"},
        {"id": 41, "name": "Samsung Galaxy S24 (Base model)"},
        {"id": 42, "name": "Samsung Galaxy S24 Plus"},
        {"id": 43, "name": "Чехол для S24 Ultra"}
    ]
    run_test_case("No Match Scenario", t4_target, t4_catalog, -1, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 5: Интеграционный тест (TF-IDF + LLM)
    # Список кандидатов больше 5. Проверяем, что TF-IDF вытащит нужный ID в топ-5,
    # а LLM затем выберет его.
    # ----------------------------------------------------------
    t5_target = {"name": "Logitech MX Master 3S Mouse Grey"}
    
    # Генерируем мусор, чтобы список был длинным
    t5_catalog = [
        {"id": 100 + i, "name": f"Random Cable {i}"} for i in range(10)
    ]
    # Добавляем похожие и верный
    t5_catalog.append({"id": 200, "name": "Logitech MX Keys Keyboard"})
    t5_catalog.append({"id": 201, "name": "Logitech G502 Hero"})
    t5_catalog.append({"id": 202, "name": "Мышь беспроводная Logitech MX Master 3S Performance Pale Grey"}) # Верный

    
    run_test_case("Full Pipeline (TF-IDF filtering)", t5_target, t5_catalog, 202, MODEL_NAME)

        # ----------------------------------------------------------
    # ТЕСТ 6: Большой список (15 кандидатов)
    # Цель: Проверить, что пре-фильтр (TF-IDF) не отсеет правильный товар
    # среди кучи очень похожих моделей Dell.
    # ----------------------------------------------------------
    t6_target = {
        "name": "Монитор Dell U2723QE 27\" 4K IPS Black"
    }
    
    t6_catalog = [
        # --- Группа 1: Очень похожие модели (Hard Negatives) ---
        {"id": 601, "name": "Dell P2723QE 27 4K Monitor"},     # Серия P вместо U (дешевле)
        {"id": 602, "name": "Dell UltraSharp U3223QE"},        # 32 дюйма вместо 27
        {"id": 603, "name": "Dell S2721QS 4K UHD"},            # Серия S
        {"id": 604, "name": "Dell UltraSharp U2720Q"},         # Старая модель (20 vs 23)
        {"id": 605, "name": "Dell U2722D 27 inch QHD"},        # QHD вместо 4K
        {"id": 606, "name": "Dell U2422HE"},                   # 24 дюйма
        {"id": 607, "name": "Монитор Dell E2723H"},            # Серия E

        # --- Группа 2: Мусор и конкуренты (Low Negatives) ---
        {"id": 608, "name": "LG 27UP850-W 27 inch 4K IPS"},    # Другой бренд
        {"id": 609, "name": "Dell Docking Station WD19S"},      # Аксессуар
        {"id": 610, "name": "Кабель HDMI 2.0b 3 метра"},       # Аксессуар
        {"id": 611, "name": "Чистящий набор для экранов"},     # Аксессуар
        {"id": 612, "name": "Клавиатура Dell Wired Keyboard KB216"},
        {"id": 613, "name": "Ноутбук Dell XPS 15 9520"},
        {"id": 614, "name": "Samsung ViewFinity S8"},

        # --- ПРАВИЛЬНЫЙ ОТВЕТ (Запрятан в конце) ---
        # TF-IDF должен увидеть совпадения "Dell", "UltraSharp", "27", "4K", "U2723QE"
        {"id": 615, "name": "Dell UltraSharp 27 4K USB-C Hub Monitor - U2723QE", "specs": "IPS Black Technology"}
    ]
    
    run_test_case("Heavy Load (15 candidates filtering)", t6_target, t6_catalog, 615, MODEL_NAME)