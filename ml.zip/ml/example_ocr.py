import ollama
from pydantic import BaseModel
from typing import List, Optional
from prompts import PROMPT_OCR

# 1. Определяем структуру данных, которую хотим получить
# Модель будет строго следовать этой схеме
class InvoiceItem(BaseModel):
    item_name: str
    quantity: int
    price: float

class InvoiceData(BaseModel):
    store_name: str
    date: str
    total_amount: float
    currency: str
    time: str
    INN: int
    items: List[InvoiceItem]

# Путь к вашему изображению
IMAGE_PATH = './reciept2.jpg' 

try:
    # 2. Отправляем запрос в Ollama
    response = ollama.chat(
        model='qwen3-vl:8b-instruct-q8_0',  # Или ваше название модели 'qwen3-vl-8b'
        messages=[
            {
                'role': 'user',
                'content': PROMPT_OCR,
                'images': [IMAGE_PATH]
            }
        ],
        # Ключевой момент: передаем схему Pydantic в format
        format=InvoiceData.model_json_schema(), 
        options={
            'temperature': 0  # Для OCR лучше ставить 0, чтобы модель не фантазировала
            
        }
    )

    # 3. Получаем результат
    # Ollama вернет строку JSON, которую Pydantic распарсит обратно в объект
    print(response)
    raw_json = response['message']['content']
    print("RAW JSON от модели:", raw_json)
    
    # Валидация и превращение в объект Python
    parsed_data = InvoiceData.model_validate_json(raw_json)
    
    print("\n--- Структурированные данные ---")
    print(f"Магазин: {parsed_data.store_name}")
    print(f"Итого: {parsed_data.total_amount} {parsed_data.currency}")
    for item in parsed_data.items:
        print(f"- {item.item_name}: {item.quantity} шт. по {item.price}")

except Exception as e:
    print(f"Ошибка: {e}")