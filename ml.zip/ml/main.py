import ollama
import base64
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from prompts import PROMPT_OCR, MATCH_PROMPT
import json
import logging
from typing import List, Dict, Any, Union, Optional

import ollama
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = FastAPI(title="Ollama OCR Service")
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Константы моделей
# Модель для зрения (парсинг чека)
OCR_MODEL = 'qwen3-vl:8b-instruct-q8_0'
CATEGORIZATION_MODEL = 'qwen3-vl:8b-instruct-q8_0' 

# --- 1. Обновленные Модели Данных ---

class InvoiceItem(BaseModel):
    item_name: str
    quantity: int
    price: float
    # Новые поля, которые мы будем заполнять отдельным методом
    category: Optional[str] = None
    subcategory: Optional[str] = None
    subsubcategory: Optional[str] = None

class InvoiceData(BaseModel):
    store_name: str
    date: str
    total_amount: float
    currency: str
    time: str
    INN: int
    items: List[InvoiceItem]

class ImageRequest(BaseModel):
    image_base64: str 

# Вспомогательная модель строго для ответа нейросети при категоризации
class CategoryResponse(BaseModel):
    category: str
    subcategory: str
    subsubcategory: str

# --- 2. Метод для категоризации одного товара ---

def categorize_item(item_name: str, store_context: str) -> CategoryResponse:
    """
    Принимает название товара и название магазина.
    Возвращает объект с категориями.
    """
    prompt = (
        f"Проанализируй товар и определи его иерархию категорий.\n"
        f"Магазин: {store_context}\n"
        f"Товар: {item_name}\n"
        f"Задача: Придумай Category (общая), Subcategory (более узкая) и Subsubcategory (конкретный тип).\n"
        f"Пример: 'Молоко 3.2%' -> Продукты -> Молочные изделия -> Молоко.\n"
        f"Отвечай только JSON объектом."
    )

    try:
        response = ollama.chat(
            model=CATEGORIZATION_MODEL,
            messages=[{'role': 'user', 'content': prompt}],
            # Форсируем JSON структуру для ответа
            format=CategoryResponse.model_json_schema(),
            options={'temperature': 0.1} # Низкая температура для предсказуемости
        )
        
        # Парсим ответ нейросети в Pydantic объект
        return CategoryResponse.model_validate_json(response['message']['content'])
    
    except Exception as e:
        print(f"Ошибка категоризации для '{item_name}': {e}")
        # Возвращаем заглушку в случае ошибки, чтобы не ломать весь процесс
        return CategoryResponse(
            category="Other", 
            subcategory="Other", 
            subsubcategory="Other"
        )

# --- 3. Основной эндпоинт ---

@app.post("/process-receipt", response_model=InvoiceData)
async def process_receipt(request: ImageRequest):
    try:
        # А. Обработка изображения
        if "," in request.image_base64:
            header, encoded = request.image_base64.split(",", 1)
        else:
            encoded = request.image_base64
            
        try:
            image_bytes = base64.b64decode(encoded)
        except Exception:
            raise HTTPException(status_code=400, detail="Некорректная строка Base64")

        # Б. Парсинг чека (OCR) с помощью Vision модели
        ocr_response = ollama.chat(
            model=OCR_MODEL,
            messages=[
                {
                    'role': 'user',
                    'content': PROMPT_OCR,
                    'images': [image_bytes] 
                }
            ],
            format=InvoiceData.model_json_schema(), 
            options={'temperature': 0}
        )

        # Превращаем ответ OCR в объект Python
        raw_json = ocr_response['message']['content']
        parsed_data = InvoiceData.model_validate_json(raw_json)
        
        # В. Обогащение данными (Категоризация)
        # Проходим по списку товаров, который мы ТОЛЬКО ЧТО получили из OCR
        print(f"Начало категоризации {len(parsed_data.items)} товаров...")
        
        for item in parsed_data.items:
            # Вызываем метод категоризации для текущего товара
            cats = categorize_item(item.item_name, parsed_data.store_name)
            
            # Обновляем поля товара
            item.category = cats.category
            item.subcategory = cats.subcategory
            item.subsubcategory = cats.subsubcategory

        # Возвращаем итоговый JSON, где товары уже с категориями
        return parsed_data

    except ollama.ResponseError as e:
        raise HTTPException(status_code=500, detail=f"Ошибка Ollama: {str(e)}")
    except Exception as e:
        print(f"Internal Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    


# Настройка логирования


# --- Pydantic Модели для валидации входных/выходных данных ---

class Product(BaseModel):
    id: Union[int, str]
    # Остальные поля могут быть любыми, поэтому используем extra="allow"
    # или просто принимаем словарь, но для валидации id лучше так.
    class Config:
        extra = "allow"

class MatchRequest(BaseModel):
    target: Dict[str, Any]
    candidates: List[Dict[str, Any]]
    top_k: int = Field(default=5, description="Количество кандидатов для фильтрации TF-IDF")

class MatchResponse(BaseModel):
    match_id: Union[int, str]
    reasoning: Optional[str] = None
    status: str

# --- Вспомогательные функции ---

def json_to_text(data: Any) -> str:
    """Превращает JSON в строку для векторного анализа."""
    if isinstance(data, dict):
        # Исключаем ID из текстового представления, чтобы не сбивать TF-IDF числами ID
        return " ".join([str(v) for k, v in data.items() if k != 'id'])
    return str(data)

def get_top_candidates(target_json: Dict, candidates_list: List[Dict], top_k: int = 5) -> List[Dict]:
    """
    Быстрый фильтр через TF-IDF.
    """
    if not candidates_list:
        return []
        
    if len(candidates_list) <= top_k:
        return candidates_list

    # Подготовка данных
    target_text = json_to_text(target_json)
    candidates_text = [json_to_text(c) for c in candidates_list]
    corpus = [target_text] + candidates_text
    
    try:
        # Векторизация
        vectorizer = TfidfVectorizer().fit_transform(corpus)
        vectors = vectorizer.toarray()
        
        # Считаем схожесть целевого (0) со всеми остальными
        cosine_similarities = cosine_similarity(vectors[0:1], vectors[1:]).flatten()
        
        # Берем индексы лучших
        top_indices = cosine_similarities.argsort()[-top_k:][::-1]
        
        return [candidates_list[i] for i in top_indices]
    except Exception as e:
        logger.error(f"TF-IDF Error: {e}")
        # В случае ошибки векторизации возвращаем срез списка, чтобы не ломать пайплайн
        return candidates_list[:top_k]

# --- Основная логика ---

@app.post("/match", response_model=MatchResponse)
def match_products(request: MatchRequest):
    """
    Эндпоинт для сопоставления товаров.
    """
    target_json = request.target
    candidates_list = request.candidates
    
    # 1. Фильтрация (TF-IDF)
    logger.info(f"Starting matching. Candidates count: {len(candidates_list)}")
    top_candidates = get_top_candidates(target_json, candidates_list, top_k=request.top_k)
    
    if not top_candidates:
        return MatchResponse(match_id=-1, reasoning="No candidates provided", status="no_candidates")

    # 2. Подготовка промпта
    

    user_prompt = f"""
    TARGET PRODUCT:
    {json.dumps(target_json, ensure_ascii=False)}

    CANDIDATE LIST:
    {json.dumps(top_candidates, ensure_ascii=False)}
    
    Which candidate is the same product as the target?
    """

    try:
        response = ollama.chat(
            model=CATEGORIZATION_MODEL,
            messages=[
                {'role': 'system', 'content': MATCH_PROMPT},
                {'role': 'user', 'content': user_prompt},
            ],
            format='json',
            options={'temperature': 0}
        )
        
        # 4. Парсинг ответа
        content = response['message']['content']
        logger.info(f"Ollama raw response: {content}")
        
        result_data = json.loads(content)
        match_id = result_data.get("match_id", -1)
        reasoning = result_data.get("reasoning", "No reasoning provided")
        
        return MatchResponse(
            match_id=match_id, 
            reasoning=reasoning,
            status="success"
        )

    except ollama.ResponseError as e:
        logger.error(f"Ollama API Error: {e}")
        raise HTTPException(status_code=502, detail=f"Ollama model error: {str(e)}")
    except json.JSONDecodeError:
        logger.error("Failed to parse JSON from Ollama")
        raise HTTPException(status_code=500, detail="Model returned invalid JSON")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health_check():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)