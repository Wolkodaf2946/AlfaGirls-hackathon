import cv2
import requests
import webbrowser
import json
import sys
import datetime

# Конфигурация
VERIFICATION_SERVER_URL = "http://localhost:8080/match_authors"

def scan_qr_code(image_path=None):
    print(f"[*] Чтение QR-кода из: {image_path}...")
    # Загружаем изображение
    img = cv2.imread(image_path)
    if img is None:
        print("[-] Ошибка: Не удалось загрузить изображение.")
        return None

    # Инициализируем детектор QR
    detector = cv2.QRCodeDetector()
    
    # Декодируем
    data, bbox, _ = detector.detectAndDecode(img)
    
    if data:
        print(f"[+] QR декодирован: {data}")
        return data
    else:
        print("[-] QR код не найден или не распознан.")
        return None

def check_smart_contract(qr_data):
    print(f"[*] Отправка запроса на верификацию: {VERIFICATION_SERVER_URL}")
    
    payload = {
        "qr_raw_data": qr_data,
    }

    try:
        response = requests.post(VERIFICATION_SERVER_URL, json=payload, timeout=5)
        
        if response.status_code == 200:
            result = response.json()
            return result.get("approved", False), result.get("reason", "")
        else:
            print(f"[-] Ошибка сервера: {response.status_code}")
            return False, "Server Error"
            
    except requests.exceptions.ConnectionError:
        print("[-] Не удалось подключиться к серверу проверки.")
        return False, "Connection Error"

def execute_payment(payment_url):
    """
    Инициализация платежа. 
    В реальности здесь был бы вызов API банка с цифровой подписью.
    Для примера мы открываем ссылку СБП в браузере (Deep Link).
    """
    print("\n" + "="*40)
    print(">>> ИНИЦИАЛИЗАЦИЯ ПЛАТЕЖА <<<")
    print(f"Перевод по ссылке: {payment_url}")
    print("="*40 + "\n")
    

def main():
    # 1. Сканируем (подставьте путь к картинке с QR кодом СБП)
    # Если нет картинки, можно сгенерировать тестовый QR в интернете
    qr_url = scan_qr_code("qr-3.jpg") 
    
    if not qr_url:
        return

    # Проверка: действительно ли это ссылка СБП (опционально)
    if "qr.nspk.ru" not in qr_url and "http" not in qr_url:
        print("[-] Это не платежный QR-код.")
        # return # Пока закомментируем, чтобы вы могли тестить на любых QR

    # 2. Логика "Смарт-контракта"
    is_approved, reason = check_smart_contract(qr_url)

    # 3. Принятие решения
    if is_approved:
        print(f"[OK] Проверка пройдена: {reason}")
        execute_payment(qr_url)
    else:
        print(f"[STOP] ПЛАТЕЖ ЗАБЛОКИРОВАН. Причина: {reason}")

if __name__ == "__main__":
    # Создайте файл test_qr.png с любым QR кодом перед запуском!
    main()