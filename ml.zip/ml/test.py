import requests
import base64
import json
import os

# --- НАСТРОЙКИ ---
# Укажи путь к твоему файлу с чеком
IMAGE_PATH = "reciept2.jpg" 
# Адрес твоего сервера
API_URL = "http://localhost:8000/process-receipt"

def main():
    # 1. Проверяем наличие файла
    if not os.path.exists(IMAGE_PATH):
        print(f"❌ Ошибка: Файл '{IMAGE_PATH}' не найден.")
        print("Положите файл чека в ту же папку или укажите полный путь.")
        return

    print(f"🔄 Подготовка изображения: {IMAGE_PATH}...")

    # 2. Кодируем изображение в Base64
    try:
        with open(IMAGE_PATH, "rb") as image_file:
            # Считываем байты -> кодируем в base64 байты -> декодируем в строку utf-8
            base64_string = base64.b64encode(image_file.read()).decode('utf-8')
    except Exception as e:
        print(f"❌ Ошибка при чтении файла: {e}")
        return

    # 3. Формируем JSON тело запроса
    payload = {
        "image_base64": base64_string
    }

    # 4. Отправляем запрос
    print(f"🚀 Отправка запроса на {API_URL}...")
    print("⏳ Ожидание ответа (это может занять время из-за генерации категорий)...")

    try:
        response = requests.post(API_URL, json=payload, timeout=120) # timeout побольше, т.к. LLM думает долго

        # 5. Обрабатываем ответ
        if response.status_code == 200:
            data = response.json()
            
            print("\n✅ УСПЕШНО! Получены данные:\n")
            
            # Выводим общую информацию
            print(f"Магазин: {data.get('store_name')}")
            print(f"Дата: {data.get('date')}")
            print(f"Итого: {data.get('total_amount')} {data.get('currency')}")
            print("-" * 50)
            print(f"{'ТОВАР':<30} | {'КАТЕГОРИЯ':<20} | {'ПОДКАТЕГОРИЯ'}")
            print("-" * 50)

            # Выводим товары с их новыми категориями
            for item in data.get('items', []):
                name = item['item_name'][:28] + ".." if len(item['item_name']) > 28 else item['item_name']
                cat = item['category'] or "N/A"
                sub = item['subcategory'] or "N/A"
                print(f"{name:<30} | {cat:<20} | {sub}")
                
            # Если хочешь увидеть полный JSON раскомментируй строку ниже:
            # print(json.dumps(data, indent=4, ensure_ascii=False))

            print("Full json:")
            print(data)
            
        else:
            print(f"❌ Ошибка сервера: {response.status_code}")
            print(response.text)

    except requests.exceptions.ConnectionError:
        print(f"❌ Не удалось подключиться к серверу по адресу {API_URL}.")
        print("Убедитесь, что сервер запущен (uvicorn run ...).")
    except requests.exceptions.ReadTimeout:
        print("❌ Сервер долго не отвечал (Timeout). Возможно, чек слишком длинный.")
    except Exception as e:
        print(f"❌ Произошла ошибка: {e}")

if __name__ == "__main__":
    main()

import requests
import json
import time

# Конфигурация
API_URL = "http://127.0.0.1:8000/match"

# Выбери модель, которая у тебя есть в Ollama (llama3, mistral, qwen2.5 и т.д.)
# MODEL_NAME = "llama3" 
MODEL_NAME = "qwen2.5:latest" # Пример

def run_test_case_api(test_name, target, catalog, expected_id, model):
    """
    Отправляет запрос на сервер и проверяет результат.
    """
    print(f"\n{'='*70}")
    print(f"TEST: {test_name}")
    print(f"{'='*70}")

    payload = {
        "target": target,
        "candidates": catalog,
        "model_name": model,
        "top_k": 5 # Сколько кандидатов оставить после TF-IDF фильтра
    }

    try:
        start_time = time.time()
        
        # Отправляем запрос
        response = requests.post(API_URL, json=payload)
        
        duration = time.time() - start_time

        if response.status_code == 200:
            data = response.json()
            predicted_id = data.get("match_id")
            reasoning = data.get("reasoning")
            status = data.get("status")

            print(f"⏱️  Time taken: {duration:.2f}s")
            print(f"🧠 Model Reasoning: {reasoning}")
            print(f"-"*30)
            print(f"[RESULT] Expected: {expected_id} | Got: {predicted_id}")
            
            # Сравнение (приводим к int, если id числовые, для надежности)
            is_match = False
            if isinstance(expected_id, int) and isinstance(predicted_id, int):
                is_match = expected_id == predicted_id
            else:
                is_match = str(expected_id) == str(predicted_id)

            if is_match:
                print("✅ SUCCESS")
            else:
                print("❌ FAILED")
        
        else:
            print(f"❌ SERVER ERROR: {response.status_code}")
            print(f"Details: {response.text}")

    except requests.exceptions.ConnectionError:
        print(f"❌ CONNECTION ERROR: Не удалось подключиться к {API_URL}")
        print("Убедитесь, что сервер запущен (uvicorn main:app --reload)")
    except Exception as e:
        print(f"❌ UNEXPECTED ERROR: {e}")

if __name__ == "__main__":
    print(f"🚀 Запуск тестов через API на модели: {MODEL_NAME}\n")
    
    # Проверка доступности сервера перед началом
    try:
        requests.get("http://127.0.0.1:8000/health", timeout=2)
    except:
        print("⚠️  Сервер недоступен! Запустите 'uvicorn main:app' в другом терминале.")
        exit(1)

    # ----------------------------------------------------------
    # ТЕСТ 1: Тонкие различия (Pro vs Non-Pro vs Аксессуар)
    # ----------------------------------------------------------
    t1_target = {
        "title": "iPhone 13 Pro 256GB Graphite",
        "price": 90000
    }
    t1_catalog = [
        {"id": 10, "name": "Apple iPhone 13 256GB (Not Pro)"},
        {"id": 11, "name": "Case for iPhone 13 Pro Silicone"}, 
        {"id": 12, "name": "Apple iPhone 13 Pro 128GB"},       
        {"id": 13, "name": "Смартфон Apple iPhone 13 Pro 256GB, Графитовый"} 
    ]
    run_test_case_api("Distractors & Model Check", t1_target, t1_catalog, 13, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 2: Проверка количества (Rule #2)
    # ----------------------------------------------------------
    t2_target = {
        "name": "Coca-Cola Classic, 0.33л (Упаковка 12 штук)",
        "attr": "Pack of 12"
    }
    t2_catalog = [
        {"id": 20, "name": "Coca-Cola 0.33l can", "desc": "Single unit"},  
        {"id": 21, "name": "Coca-Cola 0.33l x 6 pack"},                     
        {"id": 22, "name": "Напиток Coca-Cola 330мл ж/б (12 шт в уп)"},     
        {"id": 23, "name": "Pepsi Cola 12 pack"}
    ]
    run_test_case_api("Quantity Mismatch Rule", t2_target, t2_catalog, 22, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 3: Грязные данные и единицы измерения
    # ----------------------------------------------------------
    t3_target = {
        "raw": "Кофе в зернах Lavazza Oro 1кг пакет"
    }
    t3_catalog = [
        {"id": 30, "title": "Lavazza Qualita Oro Ground 250g"},
        {"id": 31, "title": "Lavazza Oro Coffee Beans 1000g"}, 
        {"id": 32, "title": "Lavazza Rossa 1kg"}
    ]
    run_test_case_api("Units Conversion (1kg vs 1000g)", t3_target, t3_catalog, 31, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 4: No Match (Rule #5)
    # ----------------------------------------------------------
    t4_target = {
        "name": "Samsung Galaxy S24 Ultra 512GB"
    }
    t4_catalog = [
        {"id": 40, "name": "Samsung Galaxy S23 Ultra"},
        {"id": 41, "name": "Samsung Galaxy S24 (Base model)"},
        {"id": 42, "name": "Samsung Galaxy S24 Plus"},
        {"id": 43, "name": "Чехол для S24 Ultra"}
    ]
    run_test_case_api("No Match Scenario", t4_target, t4_catalog, -1, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 5: Интеграционный тест (TF-IDF + LLM)
    # ----------------------------------------------------------
    t5_target = {"name": "Logitech MX Master 3S Mouse Grey"}
    
    # Генерируем мусор
    t5_catalog = [
        {"id": 100 + i, "name": f"Random Cable {i}"} for i in range(10)
    ]
    t5_catalog.append({"id": 200, "name": "Logitech MX Keys Keyboard"})
    t5_catalog.append({"id": 201, "name": "Logitech G502 Hero"})
    t5_catalog.append({"id": 202, "name": "Мышь беспроводная Logitech MX Master 3S Performance Pale Grey"}) 

    run_test_case_api("Full Pipeline (TF-IDF filtering)", t5_target, t5_catalog, 202, MODEL_NAME)

    # ----------------------------------------------------------
    # ТЕСТ 6: Большой список (15 кандидатов)
    # ----------------------------------------------------------
    t6_target = {
        "name": "Монитор Dell U2723QE 27\" 4K IPS Black"
    }
    
    t6_catalog = [
        {"id": 601, "name": "Dell P2723QE 27 4K Monitor"},     
        {"id": 602, "name": "Dell UltraSharp U3223QE"},        
        {"id": 603, "name": "Dell S2721QS 4K UHD"},            
        {"id": 604, "name": "Dell UltraSharp U2720Q"},         
        {"id": 605, "name": "Dell U2722D 27 inch QHD"},        
        {"id": 606, "name": "Dell U2422HE"},                   
        {"id": 607, "name": "Монитор Dell E2723H"},            
        {"id": 608, "name": "LG 27UP850-W 27 inch 4K IPS"},    
        {"id": 609, "name": "Dell Docking Station WD19S"},      
        {"id": 610, "name": "Кабель HDMI 2.0b 3 метра"},       
        {"id": 611, "name": "Чистящий набор для экранов"},     
        {"id": 612, "name": "Клавиатура Dell Wired Keyboard KB216"},
        {"id": 613, "name": "Ноутбук Dell XPS 15 9520"},
        {"id": 614, "name": "Samsung ViewFinity S8"},
        {"id": 615, "name": "Dell UltraSharp 27 4K USB-C Hub Monitor - U2723QE", "specs": "IPS Black Technology"}
    ]
    
    run_test_case_api("Heavy Load (15 candidates filtering)", t6_target, t6_catalog, 615, MODEL_NAME)